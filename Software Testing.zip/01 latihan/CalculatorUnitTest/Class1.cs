﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculatorMachine;
using NUnit.Framework;

namespace CalculatorUnitTest
{
    public class CalculatorTest
    {
        private Calculator cal;

        [SetUp]
        public void Init() {
            cal = new Calculator();
        }

        [Test]
        public void PenambahanTest() {
            Assert.AreEqual(5, cal.Penambahan(2, 3));
        }

        [Test]
        public void PenguranganTest()
        {
            Assert.AreEqual(4, cal.Pengurangan(7, 3));
        }

        [Test]
        public void PerkalianTest()
        {
            Assert.AreEqual(10, cal.Perkalian(5, 2));
        }

        [Test]
        public void PembagianTest()
        {
            Assert.AreEqual(3, cal.Pembagian(6, 2));
        }
    }
}
