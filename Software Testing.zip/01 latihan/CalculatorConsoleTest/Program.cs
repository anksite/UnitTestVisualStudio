﻿using System;
using CalculatorMachine;

namespace CalculatorConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Demo Unit Test Dengan Console All";
            Calculator cal = new Calculator();

            Console.WriteLine("Penambahan 2 + 3 = {0}", cal.Penambahan(2, 3));
            Console.WriteLine("Pengurangan 7 - 3 = {0}", cal.Pengurangan(7, 3));
            Console.WriteLine("Perkalian 5 x 2 = {0}", cal.Perkalian(5, 2));
            Console.WriteLine("Pembagian 6 : 2 = {0}", cal.Pembagian(6, 2));

            Console.ReadKey();
        }
    }
}
